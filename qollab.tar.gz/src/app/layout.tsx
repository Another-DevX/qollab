import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";

import { SiteHeader } from "@/components/site/SiteHeader";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "Qollab · Errores cuánticos interactivos",
    template: "%s · Qollab",
  },
  description:
    "Módulo interactivo de corrección de errores cuánticos: errores de Pauli, la base de Pauli y un reto para identificarlos sobre la esfera de Bloch.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="es"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="flex min-h-full flex-col">
        <SiteHeader />
        <main className="flex-1">{children}</main>
        <footer className="border-t border-line/80">
          <div className="mx-auto flex w-full max-w-6xl flex-col items-start justify-between gap-2 px-4 py-6 text-xs text-faint sm:flex-row sm:items-center sm:px-6">
            <p>
              Qollab · Módulo 1 — Entendiendo los errores cuánticos.
            </p>
            <p className="font-mono">
              Construido con Next.js, Three.js y amor por la notación de Dirac.
            </p>
          </div>
        </footer>
      </body>
    </html>
  );
}
