import type { Metadata } from "next";

import { PauliBasisExperience } from "@/components/experience/PauliBasisExperience";

export const metadata: Metadata = {
  title: "La base de Pauli",
  description:
    "Descubre por qué {I, X, Y, Z} forma una base de todos los operadores de un cúbit a través de rotaciones continuas.",
};

export default function Page() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:py-14">
      <PauliBasisExperience />
    </div>
  );
}
