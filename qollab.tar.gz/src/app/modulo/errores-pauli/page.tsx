import type { Metadata } from "next";

import { PauliErrorsExperience } from "@/components/experience/PauliErrorsExperience";

export const metadata: Metadata = {
  title: "Errores de Pauli",
  description:
    "Aplica los errores X, Y y Z sobre cualquier estado puro y observa su rotación de π en la esfera de Bloch.",
};

export default function Page() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:py-14">
      <PauliErrorsExperience />
    </div>
  );
}
