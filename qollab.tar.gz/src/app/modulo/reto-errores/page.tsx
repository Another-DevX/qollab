import type { Metadata } from "next";

import { ErrorChallengeGame } from "@/components/experience/ErrorChallengeGame";

export const metadata: Metadata = {
  title: "Reto de errores",
  description:
    "Juego interactivo: identifica qué error de Pauli (I, X, Y o Z) transformó el estado del cúbit.",
};

export default function Page() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:py-14">
      <ErrorChallengeGame />
    </div>
  );
}
