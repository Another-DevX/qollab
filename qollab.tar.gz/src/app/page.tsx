import Link from "next/link";

import { BlochSphere } from "@/components/bloch/BlochSphere";
import { PALETTE } from "@/components/experience/pauliInfo";
import { Callout } from "@/components/ui/primitives";
import {
  KET_PLUS_I,
  blochTuple,
  blochVector,
  type BlochVector,
} from "@/lib/quantum";

const SECTIONS = [
  {
    index: "01",
    href: "/modulo/errores-pauli",
    title: "Errores de Pauli",
    description:
      "Explora un cúbit sobre la esfera de Bloch y aplica los errores X, Y y Z. Cada operador es una rotación de π alrededor de un eje.",
    accent: "#56e1ff",
  },
  {
    index: "02",
    href: "/modulo/base-pauli",
    title: "La base de Pauli",
    description:
      "Comprueba por qué cuatro matrices bastan para escribir cualquier operador de un cúbit, mediante rotaciones continuas.",
    accent: "#7f9dff",
  },
  {
    index: "03",
    href: "/modulo/reto-errores",
    title: "Reto interactivo",
    description:
      "Se aplica un error secreto a un estado aleatorio. ¿Puedes deducir cuál fue observando la esfera?",
    accent: "#ffc857",
  },
] as const;

export default function Home() {
  const heroVector: BlochVector = blochVector(KET_PLUS_I);
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:py-16">
      <section className="grid items-center gap-10 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="space-y-6">
          <p className="inline-flex items-center gap-2 rounded-full border border-line bg-surface-2/70 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-accent">
            Módulo 1 · Hackathon Quantum Unlocked
          </p>
          <h1 className="text-balance text-4xl font-semibold leading-tight tracking-tight text-ink sm:text-5xl">
            Entendiendo los{" "}
            <span className="bg-gradient-to-r from-accent to-accent-2 bg-clip-text text-transparent">
              errores cuánticos
            </span>
          </h1>
          <p className="max-w-xl text-lg leading-relaxed text-muted">
            Un recorrido visual y matemáticamente riguroso por los errores de
            Pauli: cómo transforman un cúbit, por qué forman una base completa y
            cómo reconocerlos sobre la esfera de Bloch.
          </p>
          <div className="flex flex-wrap gap-3">
            <Link
              href="/modulo/errores-pauli"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-accent px-6 text-base font-semibold text-surface transition-all hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
            >
              Empezar el módulo →
            </Link>
            <Link
              href="/modulo/reto-errores"
              className="inline-flex h-12 items-center justify-center rounded-xl border border-line bg-surface-3 px-6 text-base font-medium text-ink transition-all hover:border-accent/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
            >
              Ir directo al reto
            </Link>
          </div>
        </div>

        <div className="relative">
          <BlochSphere
            arrows={[
              {
                id: "hero",
                vector: blochTuple(heroVector),
                color: PALETTE.original,
              },
            ]}
            autoRotate
            className="animate-float h-[360px] w-full sm:h-[440px]"
            ariaLabel="Esfera de Bloch mostrando el estado |+i⟩"
          />
        </div>
      </section>

      <section className="mt-16 space-y-5">
        <h2 className="text-sm font-mono uppercase tracking-[0.25em] text-faint">
          Recorrido del módulo
        </h2>
        <div className="grid gap-4 md:grid-cols-3">
          {SECTIONS.map((section) => (
            <Link
              key={section.href}
              href={section.href}
              className="group panel flex flex-col gap-3 p-5 transition-all hover:-translate-y-0.5 hover:border-accent/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
            >
              <span
                className="font-mono text-xs tracking-widest"
                style={{ color: section.accent }}
              >
                {section.index}
              </span>
              <h3 className="text-lg font-semibold text-ink">
                {section.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted">
                {section.description}
              </p>
              <span className="mt-1 text-sm text-accent opacity-0 transition-opacity group-hover:opacity-100">
                Abrir sección →
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-16 grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          <h2 className="text-xl font-semibold text-ink">
            ¿Qué aprenderás?
          </h2>
          <ul className="space-y-2 text-sm leading-relaxed text-muted">
            {[
              "Qué es un estado puro y cómo se representa en la esfera de Bloch.",
              "Cómo actúan los operadores X, Y y Z como rotaciones de π.",
              "Por qué {I, X, Y, Z} es una base de todos los operadores de un cúbit.",
              "La diferencia entre una fase global (inobservable) y una fase relativa.",
              "Cómo distinguir errores discretos de un canal de ruido general.",
            ].map((item) => (
              <li key={item} className="flex gap-2">
                <span aria-hidden className="text-accent">
                  ·
                </span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="space-y-4">
          <Callout tone="insight" title="Rigor primero">
            Cada animación se calcula a partir del operador real sobre el
            estado. La esfera no dibuja resultados “a mano”: renderiza el vector
            de Bloch que se obtiene de aplicar la matriz.
          </Callout>
          <Callout tone="info" title="Pensado para aprender">
            La interfaz está completamente en español y funciona con ratón,
            teclado y pantalla táctil. Arrastra la esfera para rotarla.
          </Callout>
        </div>
      </section>
    </div>
  );
}
