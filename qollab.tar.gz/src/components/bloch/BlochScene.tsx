"use client";

import { Line, OrbitControls } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { useMemo } from "react";
import * as THREE from "three";

import { SceneArrow } from "./SceneArrow";
import type { BlochArrow } from "./types";

const AXES: Array<{
  key: string;
  dir: [number, number, number];
  color: string;
  label: string;
}> = [
  { key: "x", dir: [1, 0, 0], color: "#ff6b6b", label: "X" },
  { key: "y", dir: [0, 1, 0], color: "#5ee9a3", label: "Y" },
  { key: "z", dir: [0, 0, 1], color: "#7f9dff", label: "Z" },
];

const AXIS_LENGTH = 1.32;
const LABEL_AT = 1.46;

/** Textura de etiqueta generada en canvas (sin dependencias de red). */
const makeLabelTexture = (text: string, color: string): THREE.CanvasTexture => {
  const size = 128;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  if (ctx) {
    ctx.clearRect(0, 0, size, size);
    ctx.fillStyle = color;
    ctx.font = "bold 88px ui-monospace, SFMono-Regular, Menlo, monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.shadowColor = "rgba(0,0,0,0.9)";
    ctx.shadowBlur = 12;
    ctx.fillText(text, size / 2, size / 2 + 6);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
};

function AxisLabel({
  position,
  text,
  color,
}: {
  position: [number, number, number];
  text: string;
  color: string;
}) {
  const texture = useMemo(() => makeLabelTexture(text, color), [text, color]);
  return (
    <sprite position={position} scale={0.24}>
      <spriteMaterial
        map={texture}
        transparent
        depthWrite={false}
        toneMapped={false}
      />
    </sprite>
  );
}

/** Puntos de un círculo máximo en el plano indicado. */
const circlePoints = (
  plane: "xy" | "xz" | "yz",
  radius = 1,
  segments = 96,
): [number, number, number][] => {
  const points: [number, number, number][] = [];
  for (let i = 0; i <= segments; i++) {
    const a = (i / segments) * Math.PI * 2;
    const c = Math.cos(a) * radius;
    const s = Math.sin(a) * radius;
    if (plane === "xy") points.push([c, s, 0]);
    else if (plane === "xz") points.push([c, 0, s]);
    else points.push([0, c, s]);
  }
  return points;
};

function Graticule() {
  const equator = useMemo(() => circlePoints("xy"), []);
  const meridianXZ = useMemo(() => circlePoints("xz"), []);
  const meridianYZ = useMemo(() => circlePoints("yz"), []);
  return (
    <>
      <Line
        points={equator}
        color="#9fb0e0"
        lineWidth={1.1}
        transparent
        opacity={0.5}
      />
      <Line
        points={meridianXZ}
        color="#7f9dff"
        lineWidth={0.8}
        transparent
        opacity={0.16}
      />
      <Line
        points={meridianYZ}
        color="#7f9dff"
        lineWidth={0.8}
        transparent
        opacity={0.16}
      />
    </>
  );
}

interface SceneProps {
  arrows: BlochArrow[];
  showLabels: boolean;
  autoRotate: boolean;
}

type BlochSceneProps = SceneProps;

function Scene({ arrows, showLabels, autoRotate }: SceneProps) {
  return (
    <>
      <ambientLight intensity={0.8} />

      {/* Cáscara translúcida */}
      <mesh>
        <sphereGeometry args={[1, 48, 48]} />
        <meshBasicMaterial
          color="#7f9dff"
          transparent
          opacity={0.05}
          depthWrite={false}
        />
      </mesh>
      {/* Retícula de la esfera */}
      <mesh>
        <sphereGeometry args={[1, 28, 18]} />
        <meshBasicMaterial
          color="#4a5680"
          wireframe
          transparent
          opacity={0.13}
          depthWrite={false}
        />
      </mesh>

      <Graticule />

      {/* Ejes coordenados */}
      {AXES.map((axis) => (
        <Line
          key={axis.key}
          points={[
            [
              -axis.dir[0] * AXIS_LENGTH,
              -axis.dir[1] * AXIS_LENGTH,
              -axis.dir[2] * AXIS_LENGTH,
            ],
            [
              axis.dir[0] * AXIS_LENGTH,
              axis.dir[1] * AXIS_LENGTH,
              axis.dir[2] * AXIS_LENGTH,
            ],
          ]}
          color={axis.color}
          lineWidth={1.2}
          transparent
          opacity={0.6}
        />
      ))}

      {showLabels &&
        AXES.map((axis) => (
          <AxisLabel
            key={`label-${axis.key}`}
            position={[
              axis.dir[0] * LABEL_AT,
              axis.dir[1] * LABEL_AT,
              axis.dir[2] * LABEL_AT,
            ]}
            text={axis.label}
            color={axis.color}
          />
        ))}

      {/* Vectores de estado */}
      {arrows.map((arrow) => (
        <SceneArrow
          key={arrow.id}
          vector={arrow.vector}
          color={arrow.color}
          opacity={arrow.opacity}
          from={arrow.from}
        />
      ))}

      <OrbitControls
        makeDefault
        enablePan={false}
        enableDamping
        dampingFactor={0.08}
        rotateSpeed={0.85}
        minDistance={2.4}
        maxDistance={6}
        autoRotate={autoRotate}
        autoRotateSpeed={0.6}
        target={[0, 0, 0]}
      />
    </>
  );
}

export default function BlochScene({
  arrows,
  showLabels = true,
  autoRotate = false,
}: BlochSceneProps) {
  return (
    <Canvas
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      camera={{ position: [2.7, -2.5, 1.9], fov: 45, up: [0, 0, 1] }}
      style={{ background: "transparent" }}
    >
      <Scene arrows={arrows} showLabels={showLabels} autoRotate={autoRotate} />
    </Canvas>
  );
}
