"use client";

import dynamic from "next/dynamic";

import { cn } from "@/lib/cn";
import type { BlochSphereProps } from "./types";

const BlochScene = dynamic(() => import("./BlochScene"), {
  ssr: false,
  loading: () => <BlochLoader />,
});

function BlochLoader() {
  return (
    <div className="flex h-full w-full items-center justify-center">
      <div className="flex flex-col items-center gap-3 text-faint">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-line border-t-accent" />
        <span className="text-xs">Preparando la esfera de Bloch…</span>
      </div>
    </div>
  );
}

/**
 * Contenedor de la esfera de Bloch. Carga la escena 3D sólo en cliente
 * (Three.js no se ejecuta en el servidor) y reserva el espacio visual.
 */
export function BlochSphere({
  arrows,
  className,
  showLabels = true,
  autoRotate = false,
  ariaLabel,
  overlay,
}: BlochSphereProps) {
  return (
    <div
      role="img"
      aria-label={
        ariaLabel ?? "Esfera de Bloch 3D interactiva con vectores de estado"
      }
      className={cn(
        "relative isolate overflow-hidden rounded-2xl border border-line bg-surface-2",
        "shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]",
        className,
      )}
    >
      <div className="absolute inset-0">
        <BlochScene
          arrows={arrows}
          showLabels={showLabels}
          autoRotate={autoRotate}
        />
      </div>

      {/* Viñeta suave */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 90% at 50% 45%, transparent 55%, rgba(3,5,12,0.55) 100%)",
        }}
      />

      {overlay ? (
        <div className="pointer-events-none absolute left-3 top-3 z-10">
          {overlay}
        </div>
      ) : null}

      <div className="pointer-events-none absolute bottom-3 right-3 z-10 rounded-full border border-line/70 bg-surface/70 px-3 py-1 text-[10px] uppercase tracking-widest text-faint backdrop-blur">
        arrastra para rotar
      </div>
    </div>
  );
}
