"use client";

import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useState } from "react";

import { BlochSphere } from "@/components/bloch/BlochSphere";
import type { BlochArrow } from "@/components/bloch/types";
import { MathMatrix } from "@/components/math/MathMatrix";
import { PALETTE, PAULI_INFO } from "@/components/experience/pauliInfo";
import {
  Button,
  FieldRow,
  LegendItem,
  Panel,
  SectionHeading,
  Stat,
} from "@/components/ui/primitives";
import {
  PAULI_NAMES,
  blochTuple,
  blochVector,
  checkAnswer,
  formatReal,
  generateChallenge,
  pauliMatrix,
  type AnswerResult,
  type Challenge,
  type PauliName,
} from "@/lib/quantum";

interface Score {
  correct: number;
  total: number;
}

export function ErrorChallengeGame() {
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [chosen, setChosen] = useState<PauliName | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [result, setResult] = useState<AnswerResult | null>(null);
  const [round, setRound] = useState(0);
  const [score, setScore] = useState<Score>({ correct: 0, total: 0 });
  const [streak, setStreak] = useState(0);

  // Se genera en el cliente para evitar desajustes de hidratación con el SSR.
  // Es intencionalmente un efecto de montaje: el reto es aleatorio.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setChallenge(generateChallenge());
  }, []);

  const newChallenge = useCallback(() => {
    setChallenge(generateChallenge());
    setChosen(null);
    setRevealed(false);
    setResult(null);
    setRound((value) => value + 1);
  }, []);

  const restart = useCallback(() => {
    setScore({ correct: 0, total: 0 });
    setStreak(0);
    newChallenge();
  }, [newChallenge]);

  const answer = (name: PauliName) => {
    if (!challenge || revealed) return;
    const outcome = checkAnswer(challenge, name);
    setChosen(name);
    setRevealed(true);
    setResult(outcome);
    setScore((previous) => ({
      correct: previous.correct + (outcome.correct ? 1 : 0),
      total: previous.total + 1,
    }));
    setStreak((previous) => (outcome.correct ? previous + 1 : 0));
  };

  const arrows = useMemo<BlochArrow[]>(() => {
    if (!challenge) return [];
    const initialVec = blochTuple(blochVector(challenge.initial));
    const finalVec = blochTuple(blochVector(challenge.final));
    return [
      { id: "initial", vector: initialVec, color: PALETTE.original },
      {
        // La clave cambia al revelar para reproducir la animación del error.
        id: revealed ? `final-${round}` : "final-preview",
        vector: finalVec,
        color: PALETTE.error,
        opacity: revealed ? 1 : 0.85,
        from: revealed ? initialVec : undefined,
      },
    ];
  }, [challenge, revealed, round]);

  const accuracy =
    score.total > 0 ? Math.round((score.correct / score.total) * 100) : 0;

  const expectedInfo = challenge ? PAULI_INFO[challenge.error] : null;

  return (
    <section className="space-y-8">
      <SectionHeading
        eyebrow="Sección 3 · Reto interactivo"
        title="¿Qué error sufrió este qubit?"
        lead={
          <>
            Se genera un estado puro aleatorio y se le aplica un error
            <em> secreto</em> entre I, X, Y o Z. Compara el estado inicial (cian)
            con el final (ámbar) y deduce qué operador actuó.
          </>
        }
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat
          label="Aciertos"
          value={`${score.correct} / ${score.total}`}
          hint="Respuestas correctas"
          tone={PALETTE.original}
        />
        <Stat label="Precisión" value={`${accuracy}%`} hint="Sobre el total" />
        <Stat
          label="Racha"
          value={streak}
          hint="Aciertos consecutivos"
          tone={PALETTE.error}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="lg:sticky lg:top-24">
          <BlochSphere
            arrows={arrows}
            className="h-[400px] w-full sm:h-[500px] lg:h-[560px]"
            ariaLabel="Esfera de Bloch con el estado inicial y el estado final del reto"
            overlay={
              <div className="flex flex-wrap gap-2">
                <LegendItem color={PALETTE.original} label="Estado inicial" />
                <LegendItem color={PALETTE.error} label="Estado final" />
              </div>
            }
          />
        </div>

        <div className="space-y-5">
          <Panel>
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 className="text-sm font-semibold text-ink">
                ¿Qué error sufrió este qubit?
              </h2>
              <Button variant="ghost" size="sm" onClick={restart}>
                Reiniciar
              </Button>
            </div>

            {challenge ? (
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {PAULI_NAMES.map((name) => {
                  const isCorrect = revealed && name === challenge.error;
                  const isWrongChoice =
                    revealed && chosen === name && name !== challenge.error;
                  return (
                    <button
                      key={name}
                      type="button"
                      disabled={revealed}
                      onClick={() => answer(name)}
                      aria-label={`Responder ${name}`}
                      className={[
                        "flex flex-col items-center gap-1 rounded-xl border py-3 font-mono transition-all",
                        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 disabled:cursor-default",
                        isCorrect
                          ? "border-good/70 bg-good/15 text-good shadow-[0_0_24px_-10px_var(--color-good)]"
                          : isWrongChoice
                            ? "border-bad/70 bg-bad/15 text-bad"
                            : revealed
                              ? "border-line bg-surface-3/40 text-faint opacity-60"
                              : "border-line bg-surface-3/60 text-ink hover:border-accent/60 hover:bg-surface-3",
                      ].join(" ")}
                    >
                      <span className="text-2xl font-semibold">{name}</span>
                      <span className="text-[10px] uppercase tracking-wider opacity-70">
                        {PAULI_INFO[name].title}
                      </span>
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-faint">Generando reto…</p>
            )}

            {!revealed && challenge ? (
              <p className="mt-4 text-xs leading-relaxed text-faint">
                Pista: cada error de Pauli gira el vector π radianes alrededor
                de un eje. Observa hacia dónde saltó el punto.
              </p>
            ) : null}

            {revealed && challenge && expectedInfo && result ? (
              <div className="mt-4">
                <Button variant="primary" onClick={newChallenge} className="w-full">
                  Otro reto →
                </Button>
              </div>
            ) : null}
          </Panel>

          <AnimatePresence mode="wait">
            {revealed && challenge && expectedInfo && result ? (
              <motion.div
                key={round}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <Panel
                  className={
                    result.correct
                      ? "border-good/40"
                      : "border-bad/40"
                  }
                >
                  <div
                    role="status"
                    aria-live="polite"
                    className="mb-3 flex items-center gap-2"
                  >
                    <span
                      className={`text-lg ${result.correct ? "text-good" : "text-bad"}`}
                    >
                      {result.correct ? "✓ ¡Correcto!" : "✗ Casi…"}
                    </span>
                  </div>

                  <p className="text-sm leading-relaxed text-muted">
                    {result.correct ? (
                      <>
                        Identificaste bien el error: fue{" "}
                        <strong style={{ color: expectedInfo.color }}>
                          {challenge.error}
                        </strong>{" "}
                        ({expectedInfo.title}).
                      </>
                    ) : (
                      <>
                        Elegiste{" "}
                        <strong className="text-ink">{chosen}</strong>, pero el
                        error fue{" "}
                        <strong style={{ color: expectedInfo.color }}>
                          {challenge.error}
                        </strong>{" "}
                        ({expectedInfo.title}).
                      </>
                    )}
                  </p>

                  <div className="mt-4 flex flex-wrap items-center gap-4">
                    <MathMatrix
                      matrix={pauliMatrix(challenge.error)}
                      label={`${challenge.error} =`}
                      digits={0}
                      highlight
                      accent={expectedInfo.color}
                    />
                    <span
                      className="rounded-lg border border-line/70 bg-surface/50 px-3 py-2 font-mono text-xs"
                      style={{ color: expectedInfo.color }}
                    >
                      {expectedInfo.blochMap}
                    </span>
                  </div>

                  <div className="mt-4">
                    <FieldRow label="Estado inicial (x, y, z)">
                      {coordText(blochVector(challenge.initial))}
                    </FieldRow>
                    <FieldRow label="Estado final (x, y, z)">
                      {coordText(blochVector(challenge.final))}
                    </FieldRow>
                    <FieldRow label="Verificación">
                      {`${challenge.error}|ψ⟩ = |ψ′⟩`}
                    </FieldRow>
                  </div>

                  <p className="mt-3 text-xs leading-relaxed text-faint">
                    {challenge.error === "I"
                      ? "El vector no se movió: la identidad no aplica ningún cambio."
                      : expectedInfo.effect}
                  </p>
                </Panel>
              </motion.div>
            ) : null}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

function coordText(v: { x: number; y: number; z: number }): string {
  return `(${formatReal(v.x, 3)}, ${formatReal(v.y, 3)}, ${formatReal(v.z, 3)})`;
}
