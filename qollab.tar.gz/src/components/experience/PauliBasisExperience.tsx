"use client";

import { motion } from "framer-motion";
import { useMemo, useState } from "react";

import { BlochSphere } from "@/components/bloch/BlochSphere";
import type { BlochArrow } from "@/components/bloch/types";
import { Equation } from "@/components/math/Ket";
import { MathMatrix } from "@/components/math/MathMatrix";
import { PALETTE } from "@/components/experience/pauliInfo";
import { RangeSlider } from "@/components/ui/RangeSlider";
import {
  Callout,
  Chip,
  LegendItem,
  Panel,
  SectionHeading,
} from "@/components/ui/primitives";
import {
  NAMED_STATES,
  PAULI_MATRICES,
  blochTuple,
  blochVector,
  formatComplex,
  formatPi,
  ketState,
  matVec,
  normalizeAxis,
  namedStateByKey,
  pauliDecomposition,
  radToDeg,
  rotationOperator,
  type AxisName,
  type BlochVector,
  type PauliName,
} from "@/lib/quantum";

const PRESET_AXES: Array<{ key: AxisName | "custom"; label: string }> = [
  { key: "x", label: "X" },
  { key: "y", label: "Y" },
  { key: "z", label: "Z" },
  { key: "custom", label: "Personalizado" },
];

const ANGLE_SHORTCUTS: Array<{ label: string; value: number }> = [
  { label: "0", value: 0 },
  { label: "π/2", value: Math.PI / 2 },
  { label: "π", value: Math.PI },
  { label: "3π/2", value: (3 * Math.PI) / 2 },
  { label: "2π", value: 2 * Math.PI },
];

const BASIS_ORDER: readonly PauliName[] = ["I", "X", "Y", "Z"];
const BASIS_DESCRIPTION: Record<PauliName, string> = {
  I: "Identidad: deja todo igual.",
  X: "Volteo de bit.",
  Y: "Volteo de bit y fase.",
  Z: "Volteo de fase.",
};

const axisFromSpherical = (theta: number, phi: number): BlochVector => ({
  x: Math.sin(theta) * Math.cos(phi),
  y: Math.sin(theta) * Math.sin(phi),
  z: Math.cos(theta),
});

export function PauliBasisExperience() {
  const [baseKey, setBaseKey] = useState("plus");
  const [axisKey, setAxisKey] = useState<AxisName | "custom">("z");
  const [axisTheta, setAxisTheta] = useState(Math.PI / 3);
  const [axisPhi, setAxisPhi] = useState(Math.PI / 4);
  const [angle, setAngle] = useState(Math.PI / 2);

  const baseState = useMemo(
    () => namedStateByKey(baseKey)?.state ?? ketState(0, 0),
    [baseKey],
  );

  const axisVector = useMemo<BlochVector>(() => {
    if (axisKey === "custom") {
      return normalizeAxis(axisFromSpherical(axisTheta, axisPhi));
    }
    if (axisKey === "x") return { x: 1, y: 0, z: 0 };
    if (axisKey === "y") return { x: 0, y: 1, z: 0 };
    return { x: 0, y: 0, z: 1 };
  }, [axisKey, axisTheta, axisPhi]);

  const operator = useMemo(
    () => rotationOperator(axisVector, angle),
    [axisVector, angle],
  );
  const coeffs = useMemo(() => pauliDecomposition(operator), [operator]);
  const rotatedState = useMemo(
    () => matVec(operator, baseState),
    [operator, baseState],
  );

  const baseBloch = blochVector(baseState);
  const rotatedBloch = blochVector(rotatedState);

  const isEigenstate = useMemo(() => {
    const delta =
      Math.hypot(
        baseBloch.x - rotatedBloch.x,
        baseBloch.y - rotatedBloch.y,
        baseBloch.z - rotatedBloch.z,
      );
    return angle > 1e-3 && delta < 1e-6;
  }, [baseBloch, rotatedBloch, angle]);

  const nearPi = Math.abs(angle - Math.PI) < 0.02;

  const arrows: BlochArrow[] = [
    {
      id: "axis",
      vector: blochTuple(axisVector),
      color: "#94a3b8",
      opacity: 0.5,
    },
    {
      id: "base",
      vector: blochTuple(baseBloch),
      color: PALETTE.original,
    },
    {
      id: "rotated",
      vector: blochTuple(rotatedBloch),
      color: PALETTE.transformed,
    },
  ];

  return (
    <section className="space-y-8">
      <SectionHeading
        eyebrow="Sección 2 · Base de Pauli"
        title="Por qué los operadores de Pauli forman una base"
        lead={
          <>
            No hace falta un catálogo infinito de errores: <em>cualquier</em>{" "}
            operador sobre un cúbit se escribe como combinación de sólo cuatro
            matrices. Aquí lo comprobamos girando el vector de Bloch con
            rotaciones continuas.
          </>
        }
      />

      <div className="max-w-3xl space-y-3 text-[15px] leading-relaxed text-muted">
        <p>
          El espacio de matrices complejas 2×2 tiene dimensión 4 sobre ℂ (ocho
          dimensiones reales). Por eso bastan cuatro operadores independientes
          para expresarlo todo:
        </p>
      </div>

      <Equation>E = a·I + b·X + c·Y + d·Z</Equation>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {BASIS_ORDER.map((name) => (
          <div
            key={name}
            className="panel flex flex-col items-center gap-2 p-4 text-center"
          >
            <MathMatrix
              matrix={PAULI_MATRICES[name]}
              label={`${name} =`}
              digits={0}
              highlight
            />
            <p className="text-[11px] leading-snug text-faint">
              {BASIS_DESCRIPTION[name]}
            </p>
          </div>
        ))}
      </div>

      <Callout tone="insight" title="¿Por qué cuatro?">
        Las matrices de Pauli son <strong>ortogonales</strong> bajo el producto
        interno de Hilbert–Schmidt{" "}
        <span className="font-mono">Tr(σᵢ σⱼ) = 2δᵢⱼ</span> y tienen traza nula
        (salvo I). Eso las convierte en una base ortonormal del espacio de
        matrices 2×2, que es 4-dimensional.
      </Callout>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <div className="lg:sticky lg:top-24">
          <BlochSphere
            arrows={arrows}
            className="h-[400px] w-full sm:h-[500px] lg:h-[580px]"
            ariaLabel="Esfera de Bloch con el estado base, el estado rotado y el eje de rotación"
            overlay={
              <div className="flex flex-wrap gap-2">
                <LegendItem color={PALETTE.original} label="Estado base" />
                <LegendItem color={PALETTE.transformed} label="Estado rotado" />
                <LegendItem color="#94a3b8" label="Eje de rotación" />
              </div>
            }
          />
        </div>

        <div className="space-y-5">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Panel>
              <h2 className="mb-3 text-sm font-semibold text-ink">
                1. Estado base
              </h2>
              <div className="flex flex-wrap gap-2">
                {NAMED_STATES.map((named) => (
                  <Chip
                    key={named.key}
                    selected={baseKey === named.key}
                    onClick={() => setBaseKey(named.key)}
                    aria-label={`Estado ${named.label}`}
                  >
                    {named.label}
                  </Chip>
                ))}
              </div>
            </Panel>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.05 }}
          >
            <Panel>
              <h2 className="mb-3 text-sm font-semibold text-ink">
                2. Eje y ángulo de rotación
              </h2>
              <div className="flex flex-wrap gap-2">
                {PRESET_AXES.map((axis) => (
                  <Chip
                    key={axis.key}
                    selected={axisKey === axis.key}
                    onClick={() => setAxisKey(axis.key)}
                    aria-label={`Eje ${axis.label}`}
                  >
                    {axis.label}
                  </Chip>
                ))}
              </div>

              {axisKey === "custom" ? (
                <div className="mt-4 space-y-4 border-t border-line/70 pt-4">
                  <RangeSlider
                    id="axis-theta"
                    label="θ del eje"
                    value={axisTheta}
                    min={0}
                    max={Math.PI}
                    step={0.01}
                    display={`${formatPi(axisTheta)} (${radToDeg(axisTheta).toFixed(0)}°)`}
                    onChange={setAxisTheta}
                  />
                  <RangeSlider
                    id="axis-phi"
                    label="φ del eje"
                    value={axisPhi}
                    min={0}
                    max={2 * Math.PI}
                    step={0.01}
                    display={`${formatPi(axisPhi)} (${radToDeg(axisPhi).toFixed(0)}°)`}
                    onChange={setAxisPhi}
                  />
                </div>
              ) : null}

              <div className="mt-4 space-y-3 border-t border-line/70 pt-4">
                <RangeSlider
                  id="angle"
                  label="α · ángulo de rotación"
                  value={angle}
                  min={0}
                  max={2 * Math.PI}
                  step={0.005}
                  display={`${formatPi(angle)} (${radToDeg(angle).toFixed(0)}°)`}
                  onChange={setAngle}
                />
                <div className="flex flex-wrap gap-2">
                  {ANGLE_SHORTCUTS.map((shortcut) => (
                    <Chip
                      key={shortcut.label}
                      selected={Math.abs(angle - shortcut.value) < 0.01}
                      onClick={() => setAngle(shortcut.value)}
                    >
                      {shortcut.label}
                    </Chip>
                  ))}
                </div>
              </div>
            </Panel>
          </motion.div>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel>
          <h2 className="mb-3 text-sm font-semibold text-ink">
            Operator de rotación
          </h2>
          <MathMatrix
            matrix={operator}
            caption="U(α, n)"
            label="U ="
            digits={3}
            highlight
            accent={PALETTE.transformed}
          />
          <p className="mt-4 text-sm leading-relaxed text-muted">
            Con el eje unitario <span className="font-mono">n = (nₓ, n_y, n_z)</span>:
          </p>
          <Equation>
            U = cos(α/2)·I − i·sin(α/2)·(nₓX + n_y Y + n_z Z)
          </Equation>
        </Panel>

        <Panel>
          <h2 className="mb-3 text-sm font-semibold text-ink">
            Descomposición en la base de Pauli
          </h2>
          <div className="rounded-xl border border-line/70 bg-surface/50 px-4 py-3 font-mono text-sm leading-relaxed">
            <div>
              <span className="text-faint">a = </span>
              {formatComplex(coeffs.a)}
            </div>
            <div>
              <span className="text-faint">b = </span>
              {formatComplex(coeffs.b)}
            </div>
            <div>
              <span className="text-faint">c = </span>
              {formatComplex(coeffs.c)}
            </div>
            <div>
              <span className="text-faint">d = </span>
              {formatComplex(coeffs.d)}
            </div>
            <div className="mt-3 border-t border-line/70 pt-3 text-xs text-muted">
              E = a·I + b·X + c·Y + d·Z
            </div>
          </div>
          <p className="mt-3 text-xs leading-relaxed text-faint">
            Para una rotación, <span className="font-mono">a = cos(α/2)</span> y{" "}
            <span className="font-mono">
              b, c, d = −i·sin(α/2)·nₓ, −i·sin(α/2)·n_y, −i·sin(α/2)·n_z
            </span>
            . A α = π, sólo sobrevive el término del eje elegido: recuperamos un
            operador de Pauli salvo fase global.
          </p>
        </Panel>
      </div>

      {nearPi ? (
        <Callout tone="success" title="Caso discreto">
          Con α = π, la rotación es{" "}
          <span className="font-mono">
            U = −i (nₓX + n_y Y + n_z Z)
          </span>
          . Contiene toda la información de un Pauli (los Paulis discretos
          corresponden a α = π sobre X, Y o Z), pero aparecen con la fase global
          −i.
        </Callout>
      ) : null}

      {isEigenstate ? (
        <Callout tone="warning" title="Sin cambio visible">
          El estado base es un <strong>autoestado</strong> del operador para
          este eje y ángulo: la rotación sólo añade una fase global, así que el
          vector de Bloch no se mueve. Prueba otro estado base o cambia el eje.
        </Callout>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2">
        <Callout tone="insight" title="Combinación ≠ aplicación">
          <strong className="text-ink">E = aI + bX + cY + dZ</strong> es una
          suma de operadores (combinación lineal). Aplicar operadores{" "}
          <em>en secuencia</em> es un <strong>producto</strong>:{" "}
          <span className="font-mono">X·Y = iZ ≠ X + Y</span>. Son dos cosas
          distintas.
        </Callout>
        <Callout tone="info" title="Operadores vs. canales">
          Un único operador de Pauli describe un error{" "}
          <strong>discreto y coherente</strong>. El ruido físico real suele ser
          un <em>canal cuántico</em> (una mezcla probabilística de Paulis),
          como el canal de despolarización. La base de Pauli es la herramienta
          que permite describir esos canales, pero un solo Pauli no modela{" "}
          <em>todo</em> el ruido.
        </Callout>
      </div>
    </section>
  );
}
