"use client";

import { motion } from "framer-motion";
import { useMemo, useState } from "react";

import { BlochSphere } from "@/components/bloch/BlochSphere";
import type { BlochArrow } from "@/components/bloch/types";
import { Equation, MathSpan } from "@/components/math/Ket";
import { MathMatrix } from "@/components/math/MathMatrix";
import { QubitReadout } from "@/components/experience/QubitReadout";
import { PAULI_INFO, PALETTE } from "@/components/experience/pauliInfo";
import { RangeSlider } from "@/components/ui/RangeSlider";
import {
  Button,
  Callout,
  Chip,
  FieldRow,
  LegendItem,
  Panel,
  SectionHeading,
} from "@/components/ui/primitives";
import {
  KET_0,
  NAMED_STATES,
  areEquivalentUpToPhase,
  blochToSpherical,
  blochTuple,
  blochVector,
  composePauliSequence,
  formatPi,
  ketState,
  matVec,
  namedStateByKey,
  pauliMatrix,
  radToDeg,
  type PauliName,
} from "@/lib/quantum";

const ERROR_ORDER: readonly PauliName[] = ["X", "Y", "Z"];

export function PauliErrorsExperience() {
  const [baseKey, setBaseKey] = useState<string>("0");
  const [theta, setTheta] = useState(0);
  const [phi, setPhi] = useState(0);
  const [ops, setOps] = useState<PauliName[]>([]);

  const initialState = useMemo(
    () =>
      baseKey === "custom"
        ? ketState(theta, phi)
        : namedStateByKey(baseKey)?.state ?? KET_0,
    [baseKey, theta, phi],
  );

  const totalOperator = useMemo(() => composePauliSequence(ops), [ops]);
  const currentState = useMemo(
    () => matVec(totalOperator, initialState),
    [totalOperator, initialState],
  );

  const initialBloch = useMemo(() => blochVector(initialState), [initialState]);
  const currentBloch = useMemo(() => blochVector(currentState), [currentState]);
  const noObservableChange = useMemo(
    () =>
      ops.length > 0 && areEquivalentUpToPhase(initialState, currentState, 1e-6),
    [ops.length, initialState, currentState],
  );

  const lastOp = ops.length > 0 ? ops[ops.length - 1] : null;
  const lastInfo = lastOp ? PAULI_INFO[lastOp] : null;

  const arrows: BlochArrow[] = [
    {
      id: "original",
      vector: blochTuple(initialBloch),
      color: PALETTE.original,
    },
    {
      id: "current",
      vector: blochTuple(currentBloch),
      color: PALETTE.transformed,
    },
  ];

  const selectPreset = (key: string) => {
    setBaseKey(key);
    setOps([]);
    const named = namedStateByKey(key);
    if (named) {
      const spherical = blochToSpherical(named.bloch);
      setTheta(spherical.theta);
      setPhi(spherical.phi);
    }
  };

  const applyError = (name: PauliName) => {
    setOps((previous) => [...previous, name]);
  };

  const reset = () => setOps([]);

  return (
    <section className="space-y-8">
      <SectionHeading
        eyebrow="Sección 1 · Errores de Pauli"
        title="Entendiendo los errores de Pauli"
        lead={
          <>
            Un cúbit vive en una esfera. Antes de corregir errores hay que
            entender qué le hacen: cada error de Pauli es una{" "}
            <strong className="text-ink">rotación de π</strong> de la esfera
            alrededor de un eje. Explora el estado, aplica errores y observa
            cómo se mueve el vector.
          </>
        }
      />

      <div className="max-w-3xl space-y-3 text-[15px] leading-relaxed text-muted">
        <p>
          Todo estado puro de un cúbit se describe con dos ángulos (θ, φ) y se
          representa como un vector de longitud 1 sobre la superficie de la
          esfera de Bloch:
        </p>
      </div>

      <Equation>
        |ψ⟩ = cos(θ/2) |0⟩ + e<sup>iφ</sup> sin(θ/2) |1⟩
      </Equation>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        {/* Esfera de Bloch */}
        <div className="lg:sticky lg:top-24">
          <BlochSphere
            arrows={arrows}
            className="h-[400px] w-full sm:h-[500px] lg:h-[580px]"
            ariaLabel="Esfera de Bloch con el estado original y el estado transformado"
            overlay={
              <div className="flex flex-wrap gap-2">
                <LegendItem color={PALETTE.original} label="Estado original" />
                <LegendItem color={PALETTE.transformed} label="Estado actual" />
              </div>
            }
          />
        </div>

        {/* Controles */}
        <div className="space-y-5">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Panel>
              <h2 className="mb-3 text-sm font-semibold text-ink">
                1. Elige el estado inicial
              </h2>
              <div className="flex flex-wrap gap-2">
                {NAMED_STATES.map((named) => (
                  <Chip
                    key={named.key}
                    selected={baseKey === named.key}
                    onClick={() => selectPreset(named.key)}
                    aria-label={`Estado ${named.label}`}
                  >
                    {named.label}
                  </Chip>
                ))}
                <Chip
                  selected={baseKey === "custom"}
                  onClick={() => setBaseKey("custom")}
                >
                  Personalizado
                </Chip>
              </div>

              <div className="mt-4 space-y-4 border-t border-line/70 pt-4">
                <RangeSlider
                  id="theta"
                  label={
                    <>
                      θ · polar <span className="text-faint">[0, π]</span>
                    </>
                  }
                  value={theta}
                  min={0}
                  max={Math.PI}
                  step={0.01}
                  display={`${formatPi(theta)}  (${radToDeg(theta).toFixed(0)}°)`}
                  onChange={(value) => {
                    setBaseKey("custom");
                    setTheta(value);
                  }}
                />
                <RangeSlider
                  id="phi"
                  label={
                    <>
                      φ · azimutal <span className="text-faint">[0, 2π]</span>
                    </>
                  }
                  value={phi}
                  min={0}
                  max={2 * Math.PI}
                  step={0.01}
                  display={`${formatPi(phi)}  (${radToDeg(phi).toFixed(0)}°)`}
                  onChange={(value) => {
                    setBaseKey("custom");
                    setPhi(value);
                  }}
                />
                {baseKey !== "custom" ? (
                  <p className="text-[11px] text-faint">
                    Mueve un deslizador para pasar a un estado personalizado.
                  </p>
                ) : null}
              </div>
            </Panel>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.05 }}
          >
            <Panel>
              <h2 className="mb-3 text-sm font-semibold text-ink">
                2. Aplica un error de Pauli
              </h2>
              <div className="grid grid-cols-3 gap-2">
                {ERROR_ORDER.map((name) => {
                  const info = PAULI_INFO[name];
                  return (
                    <button
                      key={name}
                      type="button"
                      onClick={() => applyError(name)}
                      aria-label={`Aplicar error ${name}`}
                      className="group flex flex-col items-center gap-1 rounded-xl border border-line bg-surface-3/60 py-3 transition-all hover:border-accent/50 hover:bg-surface-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60"
                    >
                      <span
                        className="font-mono text-2xl font-semibold"
                        style={{ color: info.color }}
                      >
                        {name}
                      </span>
                      <span className="text-[10px] uppercase tracking-wider text-faint">
                        {info.title}
                      </span>
                    </button>
                  );
                })}
              </div>
              <div className="mt-4 flex items-center justify-between gap-3 border-t border-line/70 pt-4">
                <p className="text-xs text-faint">
                  Operador compuesto:{" "}
                  <span className="font-mono text-muted">
                    {ops.length > 0
                      ? `${ops
                          .slice()
                          .reverse()
                          .join(" ∘ ")} |ψ⟩`
                      : "|ψ⟩"}
                  </span>
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={reset}
                  disabled={ops.length === 0}
                >
                  Reiniciar
                </Button>
              </div>
            </Panel>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            <Panel>
              <h2 className="mb-3 text-sm font-semibold text-ink">
                3. Lee la transformación
              </h2>
              {lastInfo && lastOp ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span
                      className="font-mono text-lg font-semibold"
                      style={{ color: lastInfo.color }}
                    >
                      {lastOp}
                    </span>
                    <span className="text-sm text-muted">{lastInfo.title}</span>
                  </div>
                  <MathMatrix
                    matrix={pauliMatrix(lastOp)}
                    label={`${lastOp} =`}
                    digits={0}
                    highlight
                    accent={lastInfo.color}
                  />
                  <p className="text-sm leading-relaxed text-muted">
                    {lastInfo.effect}
                  </p>
                  <div className="rounded-lg border border-line/70 bg-surface/50 px-3 py-2">
                    <FieldRow label="En la esfera">
                      <span style={{ color: lastInfo.color }}>
                        {lastInfo.blochMap}
                      </span>
                    </FieldRow>
                    <FieldRow label="Tipo de rotación">
                      π alrededor del eje {lastOp}
                    </FieldRow>
                  </div>
                  {ops.length > 1 ? (
                    <div className="pt-1">
                      <MathMatrix
                        matrix={totalOperator}
                        caption="operador compuesto"
                        digits={3}
                      />
                    </div>
                  ) : null}
                </div>
              ) : (
                <p className="text-sm text-muted">
                  Aún no has aplicado ningún error. Cada botón aplica un
                  operador unitario y hermítico sobre el estado actual.
                </p>
              )}
            </Panel>
          </motion.div>
        </div>
      </div>

      {/* Comparación de amplitudes */}
      <div className="grid gap-4 sm:grid-cols-2">
        <QubitReadout
          title="Estado original"
          state={initialState}
          color={PALETTE.original}
          showPhaseNote
        />
        <QubitReadout
          title="Estado actual"
          state={currentState}
          color={PALETTE.transformed}
        />
      </div>

      {noObservableChange ? (
        <Callout tone="warning" title="Mismo estado físico">
          El vector de Bloch no cambió: el estado actual difiere del original
          sólo en una <strong>fase global</strong>, que no es observable. Por
          eso la esfera muestra ambos vectores superpuestos, aunque las
          amplitudes puedan tener signos distintos.
        </Callout>
      ) : null}

      <Callout tone="insight" title="Idea clave">
        Los operadores <MathSpan>X</MathSpan>, <MathSpan>Y</MathSpan> y{" "}
        <MathSpan>Z</MathSpan> son unitarios y hermíticos. Aplicarlos equivale a
        girar el vector de Bloch π radianes alrededor del eje X, Y o Z
        respectivamente. Más adelante veremos que estas cuatro matrices{" "}
        <MathSpan>I, X, Y, Z</MathSpan> forman una base de <em>todos</em> los
        operadores de un cúbit.
      </Callout>
    </section>
  );
}
