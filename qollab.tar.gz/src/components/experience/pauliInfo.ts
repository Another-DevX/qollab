import type { PauliName } from "@/lib/quantum";

/** Paleta compartida por todas las secciones del módulo. */
export const PALETTE = {
  original: "#56e1ff",
  transformed: "#ff6fb5",
  error: "#ffc857",
  basis: "#7f9dff",
} as const;

export interface PauliInfo {
  readonly name: PauliName;
  readonly title: string;
  readonly effect: string;
  readonly blochMap: string;
  readonly note: string;
  readonly color: string;
}

export const PAULI_INFO: Record<PauliName, PauliInfo> = {
  I: {
    name: "I",
    title: "Identidad",
    effect: "No aplica ningún cambio: el estado permanece igual.",
    blochMap: "(x, y, z) → (x, y, z)",
    note: "Representa la ausencia de error sobre el cúbit.",
    color: "#9aa3b8",
  },
  X: {
    name: "X",
    title: "Bit flip",
    effect: "Intercambia |0⟩ con |1⟩; el vector de Bloch gira π alrededor del eje X.",
    blochMap: "(x, y, z) → (x, −y, −z)",
    note: "Es el análogo cuántico de invertir un bit clásico.",
    color: "#ff6b6b",
  },
  Y: {
    name: "Y",
    title: "Bit + phase flip",
    effect:
      "Combina el volteo de bit con el de fase; gira π alrededor del eje Y.",
    blochMap: "(x, y, z) → (−x, y, −z)",
    note: "Y = iXZ: equivale a aplicar X y Z (salvo fase global).",
    color: "#5ee9a3",
  },
  Z: {
    name: "Z",
    title: "Phase flip",
    effect:
      "Cambia el signo de la componente |1⟩ sin alterar probabilidades; gira π alrededor del eje Z.",
    blochMap: "(x, y, z) → (−x, −y, z)",
    note: "No cambia la probabilidad de medir 0 o 1, sólo la fase relativa.",
    color: "#7f9dff",
  },
};
