import type { ReactNode } from "react";

import { cn } from "@/lib/cn";

/** Notación de Dirac en línea: <Ket>{'"'}"</Ket> produce |ψ⟩. */
export function Ket({ children }: { children: ReactNode }) {
  return (
    <span className="whitespace-nowrap font-mono text-ink">
      |{children}
      <span className="text-muted">⟩</span>
    </span>
  );
}

/** Literal de Dirac a partir de un texto, p. ej. <BraKet>0</BraKet>. */
export function BraKet({ children }: { children: ReactNode }) {
  return (
    <span className="whitespace-nowrap font-mono">
      <span className="text-muted">⟨</span>
      {children}
      <span className="text-muted">|</span>
    </span>
  );
}

/** Bloque de ecuación central. */
export function Equation({
  children,
  className,
  accent,
}: {
  children: ReactNode;
  className?: string;
  accent?: string;
}) {
  return (
    <div
      className={cn(
        "my-4 overflow-x-auto rounded-xl border border-line bg-surface/60 px-4 py-3",
        "font-mono text-sm leading-relaxed text-ink",
        className,
      )}
      style={accent ? { borderColor: accent } : undefined}
    >
      {children}
    </div>
  );
}

/** Fragmento matemático en línea resaltado. */
export function MathSpan({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span className={cn("font-mono text-[0.95em] text-accent", className)}>
      {children}
    </span>
  );
}
