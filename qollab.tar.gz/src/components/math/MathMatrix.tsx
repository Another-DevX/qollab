import { cn } from "@/lib/cn";
import { formatComplex } from "@/lib/quantum/format";
import type { Complex, Matrix2 } from "@/lib/quantum";

export interface MathMatrixProps {
  /** Matriz compleja 2×2. */
  matrix: Matrix2;
  /** Etiqueta opcional, p. ej. "X =". */
  label?: string;
  /** Encabezado pequeño encima (p. ej. el nombre del operador). */
  caption?: string;
  digits?: number;
  className?: string;
  /** Resalta las entradas no nulas con el color de acento. */
  highlight?: boolean;
  accent?: string;
}

/** Muestra una matriz 2×2 de números complejos con corchetes. */
export function MathMatrix({
  matrix,
  label,
  caption,
  digits = 3,
  className,
  highlight = false,
  accent = "var(--color-accent)",
}: MathMatrixProps) {
  const cells = [matrix[0][0], matrix[0][1], matrix[1][0], matrix[1][1]];
  return (
    <div className={cn("inline-flex flex-col gap-1", className)}>
      {caption ? (
        <span className="font-mono text-[10px] uppercase tracking-widest text-faint">
          {caption}
        </span>
      ) : null}
      <div className="flex items-center gap-2">
        {label ? (
          <span className="font-mono text-sm text-muted">{label}</span>
        ) : null}
        <div className="inline-flex items-stretch gap-2">
          <span
            aria-hidden
            className="w-1.5 rounded-l-md border-y-2 border-l-2 border-muted/60"
          />
          <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 py-1.5 font-mono text-sm tabular-nums">
            {cells.map((cell, index) => (
              <MatrixCell
                key={index}
                value={cell}
                digits={digits}
                highlight={highlight}
                accent={accent}
              />
            ))}
          </div>
          <span
            aria-hidden
            className="w-1.5 rounded-r-md border-y-2 border-r-2 border-muted/60"
          />
        </div>
      </div>
    </div>
  );
}

function MatrixCell({
  value,
  digits,
  highlight,
  accent,
}: {
  value: Complex;
  digits: number;
  highlight: boolean;
  accent: string;
}) {
  const isZero = Math.abs(value.re) < 1e-12 && Math.abs(value.im) < 1e-12;
  return (
    <span
      className="text-center transition-colors"
      style={
        highlight && !isZero
          ? { color: accent, textShadow: "0 0 14px color-mix(in srgb, currentColor 45%, transparent)" }
          : undefined
      }
    >
      {formatComplex(value, digits)}
    </span>
  );
}
