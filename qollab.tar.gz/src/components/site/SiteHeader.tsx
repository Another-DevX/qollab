"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { cn } from "@/lib/cn";

const NAV = [
  { href: "/", label: "Inicio", index: "◇" },
  { href: "/modulo/errores-pauli", label: "Errores de Pauli", index: "1" },
  { href: "/modulo/base-pauli", label: "Base de Pauli", index: "2" },
  { href: "/modulo/reto-errores", label: "Reto", index: "3" },
] as const;

export function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 border-b border-line/80 bg-surface/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-4 px-4 sm:px-6">
        <Link
          href="/"
          className="flex shrink-0 items-center gap-2.5 focus-visible:outline-none"
          aria-label="Qollab, inicio"
        >
          <span className="relative flex h-8 w-8 items-center justify-center">
            <span className="absolute inset-0 rounded-full border border-accent/50" />
            <span className="absolute inset-0 rounded-full border border-accent-2/40 [transform:rotateX(65deg)]" />
            <span className="h-2 w-2 rounded-full bg-accent shadow-[0_0_12px_var(--color-accent)]" />
          </span>
          <span className="flex flex-col leading-none">
            <span className="text-sm font-semibold tracking-tight text-ink">
              Qollab
            </span>
            <span className="text-[10px] uppercase tracking-widest text-faint">
              QEC interactivo
            </span>
          </span>
        </Link>

        <nav
          aria-label="Secciones del módulo"
          className="ml-auto flex items-center gap-1 overflow-x-auto"
        >
          {NAV.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-2 text-xs font-medium transition-colors sm:text-sm",
                  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60",
                  active
                    ? "bg-accent/12 text-accent"
                    : "text-muted hover:bg-white/5 hover:text-ink",
                )}
              >
                <span
                  className={cn(
                    "flex h-5 w-5 items-center justify-center rounded-md border font-mono text-[10px]",
                    active ? "border-accent/60" : "border-line",
                  )}
                >
                  {item.index}
                </span>
                <span className="hidden sm:inline">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
